<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PartnerSplash extends Model
{
    protected $fillable = ['image', 'color', 'is_active'];
}
